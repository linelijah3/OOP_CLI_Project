rootProject.name = "CliProject"

